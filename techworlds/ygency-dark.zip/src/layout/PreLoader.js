const PreLoader = () => {
  return (
    <div className="preloader">
      <div className="custom-loader" />
    </div>
  );
};
export default PreLoader;
